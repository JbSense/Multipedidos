import './Banner.css'

function Banner() {
    return (
        <div className="Banner">
            <img src="../assets/images/multipedidos-logo.png" alt="Multipedidos logo" />
            <p>Processo seletivo!</p>
        </div>
    )
}

export default Banner