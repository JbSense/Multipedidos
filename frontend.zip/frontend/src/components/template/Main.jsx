import './Main.css'
import { Routes, Route, Link } from "react-router-dom";
import Home from '../../pages/Home'
import CreateUser from '../../pages/CreateUser'
import ViewUsers from '../../pages/ViewUsers'
import EditUser from '../../pages/EditUser'
import Banner from '../Banner'

function Main() {
    return (
        <div className="Main">
            <Link to="/" className="back-to-home">Home</Link>
            
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/create-user" element={<CreateUser />} />
                <Route path="/view-users" element={<ViewUsers />} />
                <Route path="/edit-user/:id" element={<EditUser />} />
            </Routes>

            <Banner />
        </div>
    )
}

export default Main