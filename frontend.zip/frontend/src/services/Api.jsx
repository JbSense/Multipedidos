import axios from 'axios';

class Api {

    buildFormData(obj) {
        var formData = new FormData()
        
        if(obj != null) {
            formData.append('id', obj.id)
            formData.append('email', obj.email)
            formData.append('password', obj.password)
            return formData
        }

        return
    }

    makeRequest(props) {
        if(props.param != null) {
            var config = {
                method: props.method,
                url: `http://localhost:8000/backend/${props.action}/${props.param}`,
                data: this.buildFormData(props.obj)
            }
        } else {
            var config = {
                method: props.method,
                url: `http://localhost:8000/backend/${props.action}/`,
                data: this.buildFormData(props.obj)
            }
        }

        return axios(config).then(response => response.data)
    }
}

export default Api