import './App.css'
import Main from './components/template/Main'

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
