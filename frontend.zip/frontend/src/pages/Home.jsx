import './Home.css'
import { Link } from "react-router-dom";

function Home() {
    return (
        <div className="Home">
            <Link to="/create-user">Cadastrar usuário</Link>
            <Link to="/view-users">Ver usuários</Link>  
        </div>
    )
}

export default Home