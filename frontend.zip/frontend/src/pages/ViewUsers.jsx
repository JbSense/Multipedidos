import './ViewUsers.css'
import React, { Component } from 'react'
import {Navigate, Link } from "react-router-dom"
import Api from '../services/Api'

const initialState = {
    users: [],
    start: true
}

class ViewUsers extends Component {
    state = { ...initialState }

    setUsers() {
        const api = new Api()

        api.makeRequest({method: 'get', action: 'get-all-users', param: null, obj: null}).then(data => {
            this.setState({ users: data.data })
            return
        })
    }

    deleteUser(event, id) {
        const api = new Api()

        api.makeRequest({method: 'post', action: 'delete-user', param: id, obj: null}).then(data => {
            return <Navigate to="/" replace={true} />
        })
    }

    getUsers() {
        if(this.state.start == true) {
            this.setUsers()
            this.setState({ start: false })
        }

        return(
            this.state.users.map(user => {
                return(
                    <li className="user">
                        <p>{user.email}</p>
                        
                        <div className="options">
                            <Link to={"/edit-user/"+user.id} className="edit">Editar</Link>
                            <p className="delete" onClick={e => this.deleteUser(e, user.id)}>Apagar</p>
                        </div>
                    </li>
                )
            })
        )
    }

    render() {
        return (
            <div className="ViewUsers">
                <ul className="users">
                    { this.getUsers() }
                </ul>
            </div>
        )
    }
}

export default ViewUsers