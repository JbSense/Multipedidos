import './EditUser.css'
import React, { Component } from 'react';
import Api from '../services/Api'
import {Navigate} from "react-router-dom"

const initialState = {
    start: true,
    id: window.location.href.split('/')[4],
    email: '',
    password: ''
}

class CreateUser extends Component {
    state = { ...initialState }

    startPage() {
        const api = new Api()

        if(this.state.start == true) {
            api.makeRequest({method: 'get', action: 'get-user', param: this.state.id, obj: null}).then(data => {
                this.setState({email: data.data.email, password: data.data.password})
            })

            this.setState({start: false})
        }
    }

    writingEmail(event) {
        this.setState({ email: event.target.value })
    }

    writingPassword(event) {
        this.setState({ password: event.target.value })
    }

    saveUser(event) {
        const api = new Api()

        api.makeRequest({method: 'post', action: 'update-user', param: null, obj: { id: this.state.id, email: this.state.email, password: this.state.password}}).then(data => {
            return <Navigate to='/'/>
        })
    }

    render() {
        return (
            <div className="EditUser" onLoad={this.startPage()}>
                <p className="title">Editar usuário</p>

                <div className="form">
                    <div className="input-content email">
                        <label htmlFor="email">E-mail</label>
                        <input type="email" name="email" value={this.state.email} onChange={ e => this.writingEmail(e) } placeholder="Enter your e-mail" id="email" required />
                    </div>

                    <div className="input-content password">
                        <label htmlFor="password">Password</label>
                        <input type="password" name="password" value={this.state.password} onChange={ e => this.writingPassword(e) } placeholder="Enter your password" id="password" required />
                    </div>

                    <p className="send" onClick={ e => this.saveUser(e)}id="send">Save</p>
                </div>
            </div>
        )
    }
}

export default CreateUser